-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 02:01 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `horoluxiadb`
--

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keyword` mediumtext DEFAULT NULL,
  `meta_description` mediumtext DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `banner` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `meta_title`, `meta_keyword`, `meta_description`, `slug`, `name`, `description`, `status`, `banner`, `created_at`, `updated_at`) VALUES
(1, 'Men\'s Watch', NULL, NULL, 'mens-watch', 'Men\'s Watch', NULL, 0, 'uploads/banner/1702025041.jpg', '2023-12-08 00:44:01', '2023-12-08 01:15:15'),
(2, 'Women\'s Watch', NULL, NULL, 'womens-watch', 'Women\'s Watch', NULL, 0, 'uploads/banner/1702025413.jpg', '2023-12-08 00:50:13', '2023-12-08 00:50:13'),
(3, 'Limited Edition', NULL, NULL, 'limited-edition', 'Limited Edition', NULL, 0, 'uploads/banner/1702025427.jpg', '2023-12-08 00:50:27', '2023-12-08 00:50:27'),
(4, 'Kids Watch', NULL, NULL, 'kids-watch', 'Kids Watch', NULL, 0, 'uploads/banner/1702025445.jpeg', '2023-12-08 00:50:46', '2023-12-08 00:50:46');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_12_03_035612_create_products_table', 1),
(6, '2023_12_05_134046_create_carts_table', 1),
(7, '2023_12_06_165545_create_orderitems_table', 1),
(8, '2023_12_06_181250_create_orders_table', 1),
(9, '2023_12_06_220731_create_categories_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orderitems`
--

CREATE TABLE `orderitems` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `zip` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `payment_id` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `tracking_no` varchar(255) NOT NULL,
  `total_amount` bigint(20) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  `remark` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'kens.santos07@gmail.comapi-token', '4f1dfe33bd5204d4db388a9ad41caa72d3393bfec426773bd725b781a79b3baf', '[\"*\"]', NULL, NULL, '2023-12-08 01:25:37', '2023-12-08 01:25:37'),
(2, 'App\\Models\\User', 1, 'kens.santos07@gmail.comapi-token', 'd86d3a92a8af954aa246079d024cf2ac69dda70bfbb2cba01bc83325a779ec04', '[\"*\"]', '2023-12-13 01:50:26', NULL, '2023-12-08 01:25:47', '2023-12-13 01:50:26'),
(3, 'App\\Models\\User', 1, 'kens.santos07@gmail.comapi-token', '72dccf2be8c734d0cc241fe818d8f60fb7c24f9e9aa93d7572571e0b4df4c4f3', '[\"*\"]', '2023-12-08 03:22:27', NULL, '2023-12-08 03:21:30', '2023-12-08 03:22:27'),
(4, 'App\\Models\\User', 2, 'admin@admin.comapi-token', 'f4bb713e60710f795544e8c3c03d54ccf21e5e827e4c89de18ef0b12a0a88afc', '[\"*\"]', '2023-12-08 03:39:51', NULL, '2023-12-08 03:39:40', '2023-12-08 03:39:51'),
(5, 'App\\Models\\User', 1, 'kens.santos07@gmail.comapi-token', '065e15b201d63467eb6ffcd3c8a15e770a6582efaf11de84ee15f69667c8e8f3', '[\"*\"]', '2023-12-08 03:40:17', NULL, '2023-12-08 03:40:15', '2023-12-08 03:40:17'),
(6, 'App\\Models\\User', 2, 'admin@admin.comapi-token', '9704ebbbf2e205c13f14ff1dfc11335e70bbe26a7b756867210f86a5c11534af', '[\"*\"]', '2023-12-08 03:40:44', NULL, '2023-12-08 03:40:33', '2023-12-08 03:40:44'),
(7, 'App\\Models\\User', 3, 'test@example.comapi-token', 'f270f9bea37c27a1ce97d032a3c45541a6f6df12c5346b4cd54fc6842714935a', '[\"*\"]', '2023-12-08 03:43:22', NULL, '2023-12-08 03:43:18', '2023-12-08 03:43:22'),
(8, 'App\\Models\\User', 3, 'test@example.comapi-token', 'b326df797878de2eda12337f4eaf83a24dd8fd6561dbfd01288a9e41a222d368', '[\"*\"]', '2023-12-08 03:45:22', NULL, '2023-12-08 03:43:49', '2023-12-08 03:45:22'),
(9, 'App\\Models\\User', 2, 'admin@admin.comapi-token', '8e993d3797765a1b970a330d40981e9311ab25bd0eea285204920d6aefa96876', '[\"*\"]', '2023-12-08 03:51:16', NULL, '2023-12-08 03:46:13', '2023-12-08 03:51:16');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `brand` varchar(255) NOT NULL,
  `selling_price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `featured` tinyint(4) NOT NULL,
  `popular` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `slug`, `name`, `description`, `meta_title`, `meta_keyword`, `meta_description`, `brand`, `selling_price`, `original_price`, `quantity`, `image`, `featured`, `popular`, `status`, `created_at`, `updated_at`) VALUES
(1, '1', 'MEN_WT001', 'Patek Philippe Nautilus', 'An iconic luxury sports watch known for its distinctive porthole design and exquisite craftsmanship, often featuring complications like moon phases and perpetual calendars.', 'MEN_WT001', 'null', 'An iconic luxury sports watch known for its distinctive porthole design and exquisite craftsmanship, often featuring complications like moon phases and perpetual calendars.', 'Horoluxia', 2500.00, 2999.00, 10, 'uploads/product/1702025855.jpg', 0, 0, 0, '2023-12-08 00:57:35', '2023-12-08 02:34:51'),
(2, '1', 'MEN_WT002', 'Audemars Piguet', 'A timeless classic with a bold octagonal bezel and integrated bracelet, the Royal Oak is a pioneer in luxury steel sports watches, combining elegance with robustness.', 'MEN_WT002', NULL, 'A timeless classic with a bold octagonal bezel and integrated bracelet, the Royal Oak is a pioneer in luxury steel sports watches, combining elegance with robustness.', 'Horoluxia', 2599.00, 3999.00, 9, 'uploads/product/1702027042.jpg', 0, 0, 0, '2023-12-08 01:17:22', '2023-12-08 03:12:59'),
(3, '1', 'MEN_WT003', 'Rolex Submariner', 'The epitome of dive watches, the Submariner is a Rolex legend, celebrated for its durability, precision, and timeless design, making it a symbol of luxury and adventure.', 'MEN_WT003', NULL, NULL, 'Horoluxia', 5000.00, 5500.00, 10, 'uploads/product/1702027096.jpg', 0, 0, 0, '2023-12-08 01:18:16', '2023-12-08 01:18:16'),
(4, '1', 'MEN_WT003', 'Richard Mille RM 011', 'A cutting-edge and avant-garde timepiece, the RM 011 boasts a skeletonized design, advanced materials, and intricate complications, showcasing Richard Mille\'s commitment to innovation.', 'MEN_WT003', NULL, 'A cutting-edge and avant-garde timepiece, the RM 011 boasts a skeletonized design, advanced materials, and intricate complications, showcasing Richard Mille\'s commitment to innovation.', 'Horoluxia', 3000.00, 2500.00, 10, 'uploads/product/1702027140.jpg', 0, 0, 0, '2023-12-08 01:19:00', '2023-12-08 01:19:00'),
(5, '1', 'MEN_WT005', 'Jaeger-LeCoultre', 'A masterpiece of horological engineering, this ultra-thin watch combines classic design with a perpetual calendar complication, showcasing Jaeger-LeCoultre\'s watchmaking expertise.', 'MEN_WT005', NULL, 'A masterpiece of horological engineering, this ultra-thin watch combines classic design with a perpetual calendar complication, showcasing Jaeger-LeCoultre\'s watchmaking expertise.', 'Horoluxia', 4999.00, 5500.00, 10, 'uploads/product/1702027209.jpg', 0, 0, 0, '2023-12-08 01:20:09', '2023-12-08 01:20:09'),
(6, '1', 'MEN_WT006', 'Lange & Söhne Lange', 'A German horological masterpiece, the Lange 1 features a distinctive off-center dial and superb finishing, embodying precision and elegance from A. Lange & Söhne.', 'MEN_WT006', NULL, 'A German horological masterpiece, the Lange 1 features a distinctive off-center dial and superb finishing, embodying precision and elegance from A. Lange & Söhne.', 'Horoluxia', 2500.00, 2599.00, 10, 'uploads/product/1702027259.jpg', 0, 0, 0, '2023-12-08 01:20:59', '2023-12-08 01:20:59'),
(7, '1', 'MEN_WT007', 'Hublot Big Bang', 'Known for its bold and contemporary design, the Big Bang combines luxury with a sporty edge, featuring innovative materials like ceramic and sapphire.', 'MEN_WT007', NULL, 'Known for its bold and contemporary design, the Big Bang combines luxury with a sporty edge, featuring innovative materials like ceramic and sapphire.', 'Horoluxia', 2500.00, 2999.00, 10, 'uploads/product/1702027354.jpg', 0, 0, 0, '2023-12-08 01:22:34', '2023-12-08 01:22:34'),
(8, '1', 'MEN_WT008', 'Vacheron Constantin', 'A symbol of understated luxury, the Patrimony collection exemplifies Vacheron Constantin\'s commitment to timeless design, exceptional craftsmanship, and mechanical excellence.', 'MEN_WT008', NULL, 'A symbol of understated luxury, the Patrimony collection exemplifies Vacheron Constantin\'s commitment to timeless design, exceptional craftsmanship, and mechanical excellence.', 'Horoluxia', 7000.00, 7200.00, 10, 'uploads/product/1702027403.jpg', 0, 0, 0, '2023-12-08 01:23:23', '2023-12-08 01:23:23'),
(9, '1', 'MEN_WT009', 'Omega Seamaster', 'A high-performance dive watch with a sleek and stylish design, the Seamaster Planet Ocean is a favorite among watch enthusiasts and a testament to Omega\'s maritime heritage.', 'MEN_WT009', NULL, 'A high-performance dive watch with a sleek and stylish design, the Seamaster Planet Ocean is a favorite among watch enthusiasts and a testament to Omega\'s maritime heritage.', 'Horoluxia', 4500.00, 5699.00, 10, 'uploads/product/1702027869.jpg', 0, 0, 0, '2023-12-08 01:31:09', '2023-12-08 01:31:09'),
(10, '1', 'MEN_WT0010', 'Cartier Santos', 'An aviation-inspired timepiece, the Santos de Cartier is characterized by its square case and exposed screws, embodying Cartier\'s fusion of elegance and innovation.', 'MEN_WT0010', NULL, 'An aviation-inspired timepiece, the Santos de Cartier is characterized by its square case and exposed screws, embodying Cartier\'s fusion of elegance and innovation.', 'Horoluxia', 4500.00, 5000.00, 10, 'uploads/product/1702027935.jpg', 0, 0, 0, '2023-12-08 01:32:15', '2023-12-08 01:32:15'),
(11, '1', 'MEN_WT0011', 'IWC Schaffhausen', 'A classic and sophisticated dress watch, the Portugieser collection from IWC is renowned for its clean design, large dials, and precision timekeeping.', 'MEN_WT0011', NULL, 'A classic and sophisticated dress watch, the Portugieser collection from IWC is renowned for its clean design, large dials, and precision timekeeping.', 'Horoluxia', 4999.00, 5299.00, 10, 'uploads/product/1702028054.jpg', 0, 0, 0, '2023-12-08 01:34:14', '2023-12-08 01:34:14'),
(12, '1', 'MEN_WT0012', 'Breguet Classique', 'An embodiment of Breguet\'s watchmaking legacy, the Classique collection features traditional and refined timepieces with iconic Breguet hands, guilloché dials, and exquisite detailing.', 'MEN_WT0012', NULL, 'An embodiment of Breguet\'s watchmaking legacy, the Classique collection features traditional and refined timepieces with iconic Breguet hands, guilloché dials, and exquisite detailing.', 'Horoluxia', 3999.00, 4199.00, 10, 'uploads/product/Mens_12.jpg.jpg', 0, 0, 0, '2023-12-08 01:35:57', '2023-12-08 01:35:57'),
(13, '1', 'MEN_WT0013', 'Ulysse Nardin Marine', 'A symbol of precision and nautical heritage, the Marine Chronometer series from Ulysse Nardin combines marine-inspired aesthetics with advanced watchmaking technology.', 'MEN_WT0013', NULL, 'A symbol of precision and nautical heritage, the Marine Chronometer series from Ulysse Nardin combines marine-inspired aesthetics with advanced watchmaking technology.', 'Horoluxia', 2599.00, 1999.00, 10, 'uploads/product/Mens_13.jpg', 0, 0, 0, '2023-12-08 01:37:32', '2023-12-08 01:37:32'),
(14, '1', 'MEN_WT0014', 'Panerai Luminor', 'Known for its bold and distinctive design, the Luminor collection by Panerai features the iconic crown-protecting bridge, creating a robust and instantly recognizable timepiece.', 'MEN_WT0014', NULL, 'Known for its bold and distinctive design, the Luminor collection by Panerai features the iconic crown-protecting bridge, creating a robust and instantly recognizable timepiece.', 'Horoluxia', 2499.00, 1200.00, 10, 'uploads/product/Mens_15.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(31, '2', 'WOMEN_WT001', 'Patek Philippe ', 'An exquisite timepiece from Patek Philippe, the Golden Ellipse is a symbol of elegance with its unique elliptical shape and timeless design.', 'WOMEN_WT001', NULL, 'An exquisite timepiece from Patek Philippe, the Golden Ellipse is a symbol of elegance with its unique elliptical shape and timeless design.', 'Horoluxia', 9500.00, 12000.00, 10, 'uploads/product/Womens_1.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(32, '2', 'WOMEN_WT002', 'Audemars Piguet Royal ', 'A luxurious timepiece from Audemars Piguet, the Royal Oak Lady combines refined craftsmanship with a touch of glamour, making it a statement accessory.', 'WOMEN_WT002', NULL, 'A luxurious timepiece from Audemars Piguet, the Royal Oak Lady combines refined craftsmanship  a touch glamof our, making it a statement accessory.', 'Horoluxia', 8800.00, 11000.00, 10, 'uploads/product/Womens_2.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(33, '2', 'WOMEN_WT003', 'Rolex Datejust', 'The Datejust Pearlmaster by Rolex is a masterpiece of elegance and sophistication, featuring precious gemstones and a captivating design.', 'WOMEN_WT003', NULL, 'The Datejust Pearlmaster by Rolex is a masterpiece of elegance and sophistication, featuring precious gemstones and a captivating design.', 'Horoluxia', 9700.00, 11500.00, 10, 'uploads/product/Womens_3.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(37, '2', 'WOMEN_WT004', 'Chopard Happy Diamonds', 'Chopards Happy Diamonds collection features playful dancing diamonds  the dial adding a touch  whimsy  this luxurious timepiece.', 'WOMEN_WT004', NULL, 'Happy Diamonds collection features playful dancing diamonds  the dial adding a touch f whimsy  this luxurious timepiece.', 'Horoluxia', 9200.00, 10500.00, 10, 'uploads/product/Womens_4.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(38, '2', 'WOMEN_WT005', 'Bvlgari Serpenti', 'The Bvlgari Serpenti Seduttori  a mesmerizing watch  a serpent-inspired bracelet, embodying Bvlgaris iconic blend  glamour  style.', 'WOMEN_WT005', NULL, 'The Bvlgari Serpenti Seduttori  a mesmerizing watch a serpent-inspired bracelet, embodying Bvlgari\'s iconic blend of glamour and style.', 'Horoluxia', 9900.00, 11800.00, 10, 'uploads/product/Womens_5.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(39, '2', 'WOMEN_WT006', 'Cartier Ballon Bleu', 'The Cartier Ballon Bleu is a timeless and elegant watch with a distinctive blue sapphire cabochon crown, representing Cartiers signature sophistication.', 'WOMEN_WT006', NULL, 'The Cartier Ballon Bleu  a timeless  elegant watch  a distinctive blue sapphire cabochon crown, representing Cartier\'s signature sophistication.', 'Horoluxia', 9600.00, 11200.00, 10, 'uploads/product/Womens_6.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(40, '2', 'WOMEN_WT007', 'Omega Constellation', 'The Omega Constellation is a symbol of precision and beauty, featuring a constellation of diamonds on the dial and a refined design.', 'WOMEN_WT007', NULL, 'The Omega Constellation is a symbol of precision and beauty, featuring a constellation of diamonds on the dial and a refined design.', 'Horoluxia', 9400.00, 10700.00, 10, 'uploads/product/Womens_7.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(41, '2', 'WOMEN_WT008', 'Jaeger-LeCoultre ', 'The Jaeger-LeCoultre Reverso is a classic art-deco-inspired watch with a reversible case, offering versatility and timeless style.', 'WOMEN_WT008', NULL, 'The Jaeger-LeCoultre Reverso is a classic art-deco-inspired watch with a reversible case, offering versatility and timeless style.', 'Horoluxia', 9100.00, 10000.00, 10, 'uploads/product/Womens_8.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(42, '2', 'WOMEN_WT009', 'Breguet Reine ', 'The Breguet Reine de Naples is a regal and feminine watch, paying homage to the first wristwatch created for Queen Caroline Murat.', 'WOMEN_WT009', NULL, 'The Breguet Reine de Naples is a regal and feminine watch, paying homage to the first wristwatch created for Queen Caroline Murat.', 'Horoluxia', 9700.00, 11600.00, 10, 'uploads/product/Womens_9.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(43, '2', 'WOMEN_WT010', 'Chanel J12', 'The Chanel J12 is a contemporary and iconic watch, known for its ceramic construction and sleek design, representing Chanels modern elegance.', 'WOMEN_WT010', NULL, 'The Chanel J12  a contemporary  iconic watch, known  its ceramic construction nd sleek design, representing Chanel\'s modern elegance.', 'Horoluxia', 9300.00, 10400.00, 10, 'uploads/product/Womens_10.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(44, '2', 'WOMEN_WT011', 'Piaget Altiplano', 'The Piaget Altiplano is a marvel of ultra-thin watchmaking, combining elegance and sophistication with a minimalist design.', 'WOMEN_WT011', NULL, 'The Piaget Altiplano is a marvel of ultra-thin watchmaking, combining elegance and sophistication with a minimalist design.', 'Horoluxia', 9600.00, 10900.00, 10, 'uploads/product/Womens_11.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(45, '2', 'WOMEN_WT012', 'Hublot Big Bang ', 'The Hublot Big Bang One Click is a bold and stylish watch, featuring a fusion of materials and vibrant colors, making a statement on the wrist.', 'WOMEN_WT012', NULL, 'The Hublot Big Bang One Click is a bold and stylish watch, featuring a fusion of materials and vibrant colors, making a statement on the wrist.', 'Horoluxia', 9900.00, 11400.00, 10, 'uploads/product/Womens_12.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(46, '2', 'WOMEN_WT013', 'Ulysse Nardin ', 'The Ulysse Nardin Lady Marine is a stunning maritime-inspired watch, featuring nautical elements and impeccable craftsmanship.', 'WOMEN_WT013', NULL, 'The Ulysse Nardin Lady Marine is a stunning maritime-inspired watch, featuring nautical elements and impeccable craftsmanship.', 'Horoluxia', 9200.00, 10300.00, 10, 'uploads/product/Womens_13.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(47, '2', 'WOMEN_WT014', 'Panerai Luminor Due', 'The Panerai Luminor Due is a blend of Italian design and Swiss precision, featuring a slim profile and the iconic crown-protecting bridge.', 'WOMEN_WT014', NULL, 'The Panerai Luminor Due is a blend of Italian design and Swiss precision, featuring a slim profile and the iconic crown-protecting bridge.', 'Horoluxia', 9100.00, 9900.00, 10, 'uploads/product/Womens_14.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(48, '2', 'WOMEN_WT012', 'Big Bang ', 'The Hublot Big Bang One Click is a bold and stylish watch, featuring a fusion of materials and vibrant colors, making a statement on the wrist.', 'WOMEN_WT012', NULL, 'The Hublot Big Bang One Click is a bold and stylish watch, featuring a fusion of materials and vibrant colors, making a statement on the wrist.', 'Horoluxia', 9900.00, 11400.00, 10, 'uploads/product/Womens_15.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(61, '4', 'KIDS_WT001', 'Disney Adventure', 'The Disney Time Adventure watch is perfect for young adventurers, featuring beloved Disney characters and vibrant colors to make telling time a magical experience.', 'KIDS_WT001', NULL, 'The Disney Time Adventure watch is perfect for young adventurers, featuring beloved Disney characters and vibrant colors to make telling time a magical experience.', 'Horoluxia', 4500.00, 6000.00, 10, 'uploads/product/Kids_1.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(62, '4', 'KIDS_WT002', 'Superhero Timekeeper', 'The Superhero Squad Timekeeper is a fun and action-packed watch for young heroes, featuring their favorite superheroes to accompany them on every adventure.', 'KIDS_WT002', NULL, 'The Superhero Squad Timekeeper is a fun and action-packed watch for young heroes, featuring their favorite superheroes to accompany them on every adventure.', 'Horoluxia', 3500.00, 5000.00, 10, 'uploads/product/Kids_2.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(63, '4', 'KIDS_WT003', 'Princess Timepiece', 'The Princess Dreams Timepiece is a charming watch for young royalty, featuring enchanting princesses and sparkles to make every moment magical.', 'KIDS_WT003', NULL, 'The Princess Dreams Timepiece is a charming watch for young royalty, featuring enchanting princesses and sparkles to make every moment magical.', 'Horoluxia', 4000.00, 5500.00, 10, 'uploads/product/Kids_3.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(64, '4', 'KIDS_WT004', 'Dino Time Tracker', 'The Dino Explorer Time Tracker is a watch for young paleontologists, featuring dinosaur motifs and a built-in timer for their exciting dino adventures.', 'KIDS_WT004', NULL, 'The Dino Explorer Time Tracker is a watch for young paleontologists, featuring dinosaur motifs and a built-in timer for their exciting dino adventures.', 'Horoluxia', 3000.00, 4500.00, 8, 'uploads/product/Kids_4.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 03:12:59'),
(65, '4', 'KIDS_WT005', 'Space  Watch', 'The Space Explorer Galaxy Watch is a watch for young astronauts, featuring cosmic designs and glow-in-the-dark elements for space-themed fun.', 'KIDS_WT005', NULL, 'The Space Explorer Galaxy Watch is a watch for young astronauts, featuring cosmic designs and glow-in-the-dark elements for space-themed fun.', 'Horoluxia', 3800.00, 5200.00, 10, 'uploads/product/Kids_5.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(66, '4', 'KIDS_WT006', 'Sports Star Timekeeper', 'The Sports Star Timekeeper is a watch for young athletes, featuring sports-themed designs and a durable strap to accompany them on their active pursuits.', 'KIDS_WT006', NULL, 'The Sports Star Timekeeper is a watch for young athletes, featuring sports-themed designs and a durable strap to accompany them on their active pursuits.', 'Horoluxia', 3200.00, 4800.00, 10, 'uploads/product/Kids_6.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(67, '4', 'KIDS_WT007', 'Animal Friends Time Teller', 'The Animal Friends Time Teller is a playful watch for young animal lovers, featuring adorable creatures to make learning to tell time delightful.', 'KIDS_WT007', NULL, 'The Animal Friends Time Teller is a playful watch for young animal lovers, featuring adorable creatures to make learning to tell time delightful.', 'Horoluxia', 2800.00, 4200.00, 10, 'uploads/product/Kids_7.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(68, '4', 'KIDS_WT008', 'Robot Adventure Wristwatch', 'The Robot Adventure Wristwatch is a watch for young inventors, featuring cool robot designs and a sturdy build for their imaginative playtime.', 'KIDS_WT008', NULL, 'The Robot Adventure Wristwatch is a watch for young inventors, featuring cool robot designs and a sturdy build for their imaginative playtime.', 'Horoluxia', 3400.00, 5000.00, 10, 'uploads/product/Kids_8.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(69, '4', 'KIDS_WT009', 'Ocean Timepiece', 'The Ocean Explorer Dive Timepiece is a watch for young marine enthusiasts, featuring underwater themes and a water-resistant design for aquatic adventures.', 'KIDS_WT009', NULL, 'The Ocean Explorer Dive Timepiece is a watch for young marine enthusiasts, featuring underwater themes and a water-resistant design for aquatic adventures.', 'Horoluxia', 3600.00, 4600.00, 10, 'uploads/product/Kids_9.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(70, '4', 'KIDS_WT010', 'Fairy Timepiece', 'The Fairy Tale Fantasy Timepiece is a watch for young dreamers, featuring magical fairy tale motifs and whimsical details for a touch of enchantment.', 'KIDS_WT010', NULL, 'The Fairy Tale Fantasy Timepiece is a watch for young dreamers, featuring magical fairy tale motifs and whimsical details for a touch of enchantment.', 'Horoluxia', 4200.00, 5500.00, 10, 'uploads/product/Kids_10.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(71, '4', 'KIDS_WT011', 'Jungle Adventure', 'The Jungle Safari Adventure Watch is a watch for young explorers, featuring jungle-themed designs and a durable strap for their outdoor escapades.', 'KIDS_WT011', NULL, 'The Jungle Safari Adventure Watch is a watch for young explorers, featuring jungle-themed designs and a durable strap for their outdoor escapades.', 'Horoluxia', 3000.00, 4000.00, 10, 'uploads/product/Kids_11.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(72, '4', 'KIDS_WT012', 'Music  Watch', 'The Music Maestro Melody Watch is a watch for young music lovers, featuring musical notes and melodies to add a tuneful element to their day.', 'KIDS_WT012', NULL, 'The Music Maestro Melody Watch is a watch for young music lovers, featuring musical notes and melodies to add a tuneful element to their day.', 'Horoluxia', 3800.00, 4800.00, 10, 'uploads/product/Kids_12.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(73, '4', 'KIDS_WT013', 'Colorful Time Teller', 'The Colorful Rainbow Time Teller is a watch for young artists, featuring vibrant colors and a rainbow design to inspire creativity and joy.', 'KIDS_WT013', NULL, 'The Colorful Rainbow Time Teller is a watch for young artists, featuring vibrant colors and a rainbow design to inspire creativity and joy.', 'Horoluxia', 3200.00, 4200.00, 10, 'uploads/product/Kids_13.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(74, '4', 'KIDS_WT014', 'Robot Wristwatch', 'The Robot Adventure Wristwatch is a watch for young inventors, featuring cool robot designs and a sturdy build for their imaginative playtime.', 'KIDS_WT014', NULL, 'The Robot Adventure Wristwatch is a watch for young inventors, featuring cool robot designs and a sturdy build for their imaginative playtime.', 'Horoluxia', 3400.00, 4800.00, 10, 'uploads/product/Kids_14.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(75, '4', 'KIDS_WT015', 'Unicorn Timepiece', 'The Unicorn Fantasy Timepiece is a watch for young dreamers, featuring magical unicorn motifs and whimsical details for a touch of enchantment.', 'KIDS_WT015', NULL, 'The Unicorn Fantasy Timepiece is a watch for young dreamers, featuring magical unicorn motifs and whimsical details for a touch of enchantment.', 'Horoluxia', 4000.00, 5500.00, 8, 'uploads/product/Kids_15.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 03:12:59'),
(76, '3', 'LE_WT001', 'Omega Apollo 11', 'The Omega Speedmaster Apollo 11 is a tribute to the historic moon landing, featuring a unique dial design and limited edition numbering, making it a collector\'s dream.', 'LE_WT001', NULL, 'The Omega Speedmaster Apollo 11 is a tribute to the historic moon landing, featuring a unique dial design and limited edition numbering, making it a collector\'s dream.', 'Horoluxia', 15000.00, 20000.00, 5, 'uploads/product/Limited_1.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(77, '3', 'LE_WT002', 'Rolex Green Hulk', 'The Rolex Submariner Green Hulk is a limited edition diver\'s watch, renowned for its striking green bezel and exclusive design, making it a coveted timepiece.', 'LE_WT002', NULL, 'The Rolex Submariner Green Hulk is a limited edition diver\'s watch, renowned for its striking green bezel and exclusive design, making it a coveted timepiece.', 'Horoluxia', 18000.00, 23000.00, 5, 'uploads/product/Limited_2.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(78, '3', 'LE_WT003', 'Philippe Nautilus', 'The Patek Philippe Nautilus 40th Anniversary edition is a celebration of timeless elegance, featuring a blue dial and commemorative engraving, making it a collector\'s delight.', 'LE_WT003', NULL, 'The Patek Philippe Nautilus 40th Anniversary edition is a celebration of timeless elegance, featuring a blue dial and commemorative engraving, making it a collector\'s delight.', 'Horoluxia', 22000.00, 27000.00, 5, 'uploads/product/Limited_3.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(79, '3', 'LE_WT004', 'Audemars Piguet Royal', 'The Audemars Piguet Royal Oak Perpetual Calendar is a limited edition masterpiece, featuring a perpetual calendar complication and a stunning blue dial, making it a symbol of horological excellence.', 'LE_WT004', NULL, 'The Audemars Piguet Royal Oak Perpetual Calendar is a limited edition masterpiece, featuring a perpetual calendar complication and a stunning blue dial, making it a symbol of horological excellence.', 'Horoluxia', 25000.00, 30000.00, 5, 'uploads/product/Limited_4.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(80, '3', 'LE_WT005', 'Sapphire Rainbow', 'The Hublot Big Bang Unico Sapphire Rainbow is a limited edition marvel, featuring a transparent case adorned with a spectrum of vibrant gemstones, making it a unique and bold statement.', 'LE_WT005', NULL, 'The Hublot Big Bang Unico Sapphire Rainbow is a limited edition marvel, featuring a transparent case adorned with a spectrum of vibrant gemstones, making it a unique and bold statement.', 'Horoluxia', 28000.00, 33000.00, 5, 'uploads/product/Limited_5.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(81, '3', 'LE_WT006', 'IWC Pilots Watch', 'The IWC Pilots Watch Timezoner Spitfire is a limited edition aviation-inspired timepiece, featuring a world time function and a vintage design, making it a must-have for aviation enthusiasts.', 'LE_WT006', NULL, 'The IWC Pilots Watch Timezoner Spitfire is a limited edition aviation-inspired timepiece, featuring a world time function and a vintage design, making it a must-have for aviation enthusiasts.', 'Horoluxia', 20000.00, 25000.00, 5, 'uploads/product/Limited_6.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(82, '3', 'LE_WT007', 'Tag Heuer', 'The Tag Heuer Monaco Gulf Limited Edition is a tribute to motorsports, featuring the iconic Gulf Racing colors and a stylish square case, making it a collector\'s choice for racing enthusiasts.', 'LE_WT007', NULL, 'The Tag Heuer Monaco Gulf Limited Edition is a tribute to motorsports, featuring the iconic Gulf Racing colors and a stylish square case, making it a collector\'s choice for racing enthusiasts.', 'Horoluxia', 18000.00, 22000.00, 5, 'uploads/product/Limited_7.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(83, '3', 'LE_WT008', 'Panerai Carbotech', 'The Panerai Luminor Marina Carbotech is a limited edition marvel, featuring a high-tech carbon fiber case and a bold design, making it a statement piece for watch connoisseurs.', 'LE_WT008', NULL, 'The Panerai Luminor Marina Carbotech is a limited edition marvel, featuring a high-tech carbon fiber case and a bold design, making it a statement piece for watch connoisseurs.', 'Horoluxia', 26000.00, 31000.00, 5, 'uploads/product/Limited_8.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(84, '3', 'LE_WT009', 'Chopard Eagle XL Chrono', 'The Chopard Alpine Eagle XL Chrono is a limited edition chronograph, featuring a sleek stainless steel case and a precision movement, making it a symbol of performance and luxury.', 'LE_WT009', NULL, 'The Chopard Alpine Eagle XL Chrono is a limited edition chronograph, featuring a sleek stainless steel case and a precision movement, making it a symbol of performance and luxury.', 'Horoluxia', 22000.00, 26000.00, 5, 'uploads/product/Limited_9.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(85, '3', 'LE_WT010', 'Jaeger-LeCoultre Reverso', 'The Jaeger-LeCoultre Reverso Tribute Nonantième is a limited edition masterpiece, featuring a unique calendar complication and an elegant design, making it a collector\'s delight.', 'LE_WT010', NULL, 'The Jaeger-LeCoultre Reverso Tribute Nonantième is a limited edition masterpiece, featuring a unique calendar complication and an elegant design, making it a collector\'s delight.', 'Horoluxia', 24000.00, 28000.00, 5, 'uploads/product/Limited_10.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(86, '3', 'LE_WT011', 'Bvlgari Octo', 'The Bvlgari Octo Finissimo Automatic Satin-Polished Steel is a limited edition marvel, featuring an ultra-thin profile and a satin-polished steel case, making it a symbol of contemporary elegance.', 'LE_WT011', NULL, 'The Bvlgari Octo Finissimo Automatic Satin-Polished Steel is a limited edition marvel, featuring an ultra-thin profile and a satin-polished steel case, making it a symbol of contemporary elegance.', 'Horoluxia', 26000.00, 30000.00, 5, 'uploads/product/Limited_11.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(87, '3', 'LE_WT012', 'Ulysse Free Wheel', 'The Ulysse Nardin Executive Tourbillon Free Wheel is a limited edition tourbillon masterpiece, featuring a stunning dial design and a free-floating tourbillon, making it a horological work of art.', 'LE_WT012', NULL, 'The Ulysse Nardin Executive Tourbillon Free Wheel is a limited edition tourbillon masterpiece, featuring a stunning dial design and a free-floating tourbillon, making it a horological work of art.', 'Horoluxia', 32000.00, 36000.00, 5, 'uploads/product/Limited_12.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(88, '3', 'LE_WT013', 'Pate Pilot Time', 'The Patek Philippe Calatrava Pilot Travel Time is a limited edition pilot\'s watch, featuring a dual time zone function and a classic Calatrava design, making it a blend of style and functionality.', 'LE_WT013', NULL, 'The Patek Philippe Calatrava Pilot Travel Time is a limited edition pilot\'s watch, featuring a dual time zone function and a classic Calatrava design, making it a blend of style and functionality.', 'Horoluxia', 28000.00, 32000.00, 5, 'uploads/product/Limited_13.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(89, '3', 'LE_WT014', 'Audemars Chronograph', 'The Audemars Piguet Royal Oak Offshore Tourbillon Chronograph is a limited edition tourbillon chronograph, featuring a bold design and intricate complications, making it a symbol of luxury and precision.', 'LE_WT014', NULL, 'The Audemars Piguet Royal Oak Offshore Tourbillon Chronograph is a limited edition tourbillon chronograph, featuring a bold design and intricate complications, making it a symbol of luxury and ', 'Horoluxia', 28000.00, 32000.00, 5, 'uploads/product/Limited_13.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(90, '3', 'LE_WT015', 'Marina Carbotech', 'The Panerai Luminor Marina Carbotech is a limited edition marvel, featuring a high-tech carbon fiber case and a bold design, making it a statement piece for watch connoisseurs.', 'LE_WT008', NULL, 'The Panerai Luminor Marina Carbotech is a limited edition marvel, featuring a high-tech carbon fiber case and a bold design, making it a statement piece for watch connoisseurs.', 'Horoluxia', 26000.00, 31000.00, 5, 'uploads/product/Limited_8.jpg', 0, 0, 0, '2023-12-08 01:38:37', '2023-12-08 01:38:37'),
(91, '5', 'test-product', 'Test Product', 'Lorem Ipsum', 'Test Category', 'null', 'Lorem Ipsum', 'Horoluxia', 2000.00, 5000.00, 10, 'uploads/product/MensWatches1.jpg', 1, 1, 0, '2023-12-08 03:49:19', '2023-12-08 03:50:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(2, 'Admin', 'Admin', 'admin@admin.com', NULL, '$2y$12$qBTIJR1cvoecJXYEBxXqweA7QYPwPRDovD.cPCDZnNsDAUyuwU/Ui', NULL, '2023-12-08 03:39:40', '2023-12-08 03:39:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orderitems`
--
ALTER TABLE `orderitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orderitems`
--
ALTER TABLE `orderitems`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
